package com.example.foxandroidcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
// не стал прописывать onSaveInstanceState() тк при повороте экрана ничего не сбрасывается.
    public void onSumBtnClick(View view) { // метод кнопки Сумма
        try {
            EditText el1 = (EditText)findViewById(R.id.num1);
            EditText el2 = (EditText)findViewById(R.id.num2);

            int num1 = Integer.parseInt(el1.getText().toString());
            int num2 = Integer.parseInt(el2.getText().toString());
            int result = num1 + num2;

            Intent intent = new Intent(this, SecActivity.class);
            intent.putExtra("num1",num1);
            intent.putExtra("num2",num2);
            intent.putExtra("result",result);
            startActivity(intent);
        }
       catch (NumberFormatException n) { // обработка пустого поля или ввод дробного числа (вывод сообщения, если данные не корректны)
           Toast toast = Toast.makeText(getApplicationContext(),"Wrong Value Format or Empty",Toast.LENGTH_LONG);
           toast.show();
       }
    }

}