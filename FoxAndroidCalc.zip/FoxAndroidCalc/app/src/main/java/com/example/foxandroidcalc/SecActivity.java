package com.example.foxandroidcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView textView = new TextView(this);
        textView.setTextSize(26);
        textView.setPadding(55, 110, 55, 55);
        Bundle arguments = getIntent().getExtras();

        if (arguments != null) {
            int num1 = arguments.getInt("num1");
            int num2 = arguments.getInt("num2");
            int result = arguments.getInt("result");

             if ((num1 & num2) < 0){ // если значение1 и значение2 отрицательны, то выводится (-знач1) + (-знач2) = результат
                textView.setText("(" + num1 + ")" + " + " + "(" + num2 + ")" + " = " + result);
            }
            else if (num1 < 0) { // если значение1 отрицательное, то выводится (-знач1) + знач2 = результат
                textView.setText("(" + num1 + ")" + " + " + num2 + " = " + result);
            }
            else if (num2 < 0) { // если значение2 отрицательное, то выводится знач1 + (-знач2) = результат
                textView.setText(num1 + " + " + "(" + num2 + ")" + " = " + result);}

            else { // вывод если отрицательных значений нет
                textView.setText(num1 + " + " + num2 + " = " + result);
            }
            setContentView(textView);
        }
    }
}

