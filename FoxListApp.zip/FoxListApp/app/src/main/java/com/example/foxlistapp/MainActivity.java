package com.example.foxlistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    String film1= "пицца" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView FilmsList = (ListView) findViewById(R.id.FilmsList); //получаем listview
        String[] films = getResources().getStringArray(R.array.films); //получаем ресурсы
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, films);
        FilmsList.setAdapter(adapter); //установка адаптера для списка
        FilmsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
    String films = (String) FilmsList.getAdapter().getItem(position);
                if (position == 0) {
                    String str = getString(R.string.strf1);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("Bladerunner", str);
                    FilmsList.getContext().startActivity(intent);
                }
                if (position == 1) {
                    String str = getString(R.string.strf2);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("GoodGuys", str);
                    FilmsList.getContext().startActivity(intent);
                }
                if (position == 2) {
                    String str = getString(R.string.strf3);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("Drive", str);
                    FilmsList.getContext().startActivity(intent);
                }
                if (position == 3) {
                    String str = getString(R.string.strf4);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("Pines", str);
                    FilmsList.getContext().startActivity(intent);
                }
                if (position == 4) {
                    String str = getString(R.string.strf5);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("God", str);
                    FilmsList.getContext().startActivity(intent);
                }
                if (position == 5) {
                    String str = getString(R.string.strf6);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("Fanatik", str);
                    FilmsList.getContext().startActivity(intent);
                }
                if (position == 6) {
                    String str = getString(R.string.strf7);
                    Intent intent = new Intent(FilmsList.getContext(), SecActivity.class);
                    intent.putExtra("La-La Land", str);
                    FilmsList.getContext().startActivity(intent);
                }
            }
        });
    }
}