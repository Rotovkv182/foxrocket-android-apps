package com.example.foxlistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

public class SecActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView textView = new TextView(this);
        textView.setTextSize(20);
        textView.setPadding(45, 15, 15, 15);
        Bundle arguments = getIntent().getExtras();

        String f1 = arguments.getString("Bladerunner");
        String f2 = arguments.getString("GoodGuys");
        String f3 = arguments.getString("Drive");
        String f4 = arguments.getString("Pines");
        String f5 = arguments.getString("God");
        String f6 = arguments.getString("Fanatik");
        String f7 = arguments.getString("La-La Land");

        if (f1 != null){
        textView.setText(f1);}
        if (f2 != null){
        textView.setText(f2);}
        if (f3 != null){
        textView.setText(f3);}
        if (f4 != null){
        textView.setText(f4);}
        if (f5 != null){
        textView.setText(f5);}
        if (f6 != null){
        textView.setText(f6);}
        if (f7 != null){
        textView.setText(f7);}

        setContentView(textView);
    }
}