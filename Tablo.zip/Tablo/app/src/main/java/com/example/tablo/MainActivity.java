package com.example.tablo;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    final String LOG_TAG = "myLogs";
    private Integer count_cheems=0;
    private Integer count_floppa=0;
    private static final String KEY_Cheems = "Cheems";
    private static final String KEY_Floppa = "Floppa";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            count_cheems = savedInstanceState.getInt(KEY_Cheems, 0);
            count_floppa = savedInstanceState.getInt(KEY_Floppa, 0);
        }
        Toast.makeText(this, "onCreate()", Toast.LENGTH_LONG).show();
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_Cheems, count_cheems);
        outState.putInt(KEY_Floppa, count_floppa);
        Toast.makeText(this, "onSaveInstanceState()", Toast.LENGTH_LONG).show();
        Log.d(LOG_TAG, "onSaveInstanceState");
    }

    public void onClickBtnCheems(View view){
    count_cheems++;
    TextView counterView =(TextView)findViewById(R.id.counter1);
    counterView.setText(count_cheems.toString());
        Toast.makeText(this, "onClickBtnCheems()", Toast.LENGTH_LONG).show();
        Log.d(LOG_TAG, "onClickbtnCheems");
}
    public void onClickBtnFloppa(View view){
        count_floppa++;
        TextView counterView =(TextView)findViewById(R.id.counter2);
        counterView.setText(count_floppa.toString());
        Toast.makeText(this, "onClickBtnFloppa()", Toast.LENGTH_LONG).show();
        Log.d(LOG_TAG, "onClickBtnFloppa");
    }
    public void onClickBtnReset(View view){
        count_floppa = 0;
        count_cheems = 0;
        TextView counterView =(TextView)findViewById(R.id.counter1);
        counterView.setText(count_cheems.toString());
        counterView = (TextView) findViewById(R.id.counter2);
        counterView.setText(count_floppa.toString());
        Toast.makeText(this, "onClickBtnReset()", Toast.LENGTH_LONG).show();
        Log.d(LOG_TAG, "onClickBtnReset");
    }
}